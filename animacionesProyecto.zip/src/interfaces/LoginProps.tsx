export interface LoginProps {
  onClose: () => void;
}
