export interface NoticiaProps {
    id: number;
    titulo: string;
    descripcion: string;
    contenido: string;
    imagen: string;
    fecha: string;
    autor: string;
}
