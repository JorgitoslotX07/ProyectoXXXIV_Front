export interface HomePageProps {
  onLoginClick: () => void;
  onClickOptionsPerfil: () => void;
}
