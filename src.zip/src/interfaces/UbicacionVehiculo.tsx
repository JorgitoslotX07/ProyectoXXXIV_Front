// eslint-disable-next-line @typescript-eslint/no-unused-vars
interface UbicacionVehiculo {
    id: number;
    latitud: number;
    longitud: number;
}