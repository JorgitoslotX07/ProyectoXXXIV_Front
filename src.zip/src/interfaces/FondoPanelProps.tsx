import type { ReactNode } from "react";

export interface FondoPanelProps {
    children: ReactNode;
  }

  