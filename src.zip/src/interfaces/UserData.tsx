export interface UserData {
  token: string;
}
