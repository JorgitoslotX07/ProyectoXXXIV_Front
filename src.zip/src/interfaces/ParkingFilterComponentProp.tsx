export interface ParkingFilterComponentProp {
    mostrar: boolean;
    onToggle: () => void;
}
