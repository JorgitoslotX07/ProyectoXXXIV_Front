export interface ImageWebCameProps {
  setImage: (e: string) => void;
}
