export interface BotonAgregarProps {
    text: string;
    onClick: () => void;
}