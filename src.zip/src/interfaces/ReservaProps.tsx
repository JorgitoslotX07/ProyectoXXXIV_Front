export interface Reserva {
    id: string;
    vehiculo: string;
    fechaInicio: string;
    fechaFin: string;
    estado: string;
  }