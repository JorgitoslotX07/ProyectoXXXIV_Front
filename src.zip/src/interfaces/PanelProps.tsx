export interface VolverProps {
    url: string;
}

export interface TituloProps {
    titulo: string;
    runtaOut: string;
}