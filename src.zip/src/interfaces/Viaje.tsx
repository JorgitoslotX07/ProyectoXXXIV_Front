export interface Viaje {
    id: number;
    vehiculoId: number;
    origen: string;
    destino: string;
    fecha: string;
  }