export interface DesplegablePerfilProps {
  optionsPerfil: boolean;
  setOptionsPerfil: (value: boolean) => void;
}
