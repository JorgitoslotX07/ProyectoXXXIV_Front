export interface Historial {
    id: number;
    vehiculoId: number;
    fechaInicio: string;
    fechaFin: string;
    kmRecorridos: number;
}