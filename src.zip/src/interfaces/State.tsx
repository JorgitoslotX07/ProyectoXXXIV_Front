export type State = {
  token: string | null;
  setToken: (user: string) => void;
};
