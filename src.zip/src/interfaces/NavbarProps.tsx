export interface NavbarProps {
  onLoginClick: () => void;
}
