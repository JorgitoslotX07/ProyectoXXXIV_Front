import { NotiToastComponent } from "../../components/NotiToastComponents/NotiToastComponet";
import { RegisterComponent } from "../../components/Form/RegisterComponent/RegisterComponent";
import { useEffect, useState, type FC } from "react";

interface Props {
  modoClaro: boolean;
}

export const RegistroPage: FC<Props> = ({ modoClaro }) => {
  return (
    <div
      className={`${modoClaro
        ? "bg-gradient-to-br from-[#e0fbea] to-[#fef9c3] text-[#1f2937]"
        : "bg-[rgb(22,23,64)] text-white"
        } min-h-screen flex transition-colors duration-300`}
    >
      {/* Panel del formulario */}
      <div
        className={`w-full md:w-1/2 flex items-center justify-center p-10 ${
          modoClaro
            ? "bg-white/80 border border-gray-200"
            : "bg-[rgba(17,25,40,0.75)] border border-[rgba(255,255,255,0.125)]"
        } backdrop-blur-[16px] backdrop-saturate-[180%]`}
      >
        <div className="w-full max-w-md">
          <RegisterComponent />
        </div>
      </div>

      {/* Imagen decorativa */}
      <div
        className="hidden md:block md:w-1/2 bg-cover bg-center"
        style={{
          backgroundImage: modoClaro
            ? "url('/fondoFastSeartchClaro.jpeg')"
            : "url('/fondoFastSeartch.webp')",
        }}
      />

      <NotiToastComponent />
    </div>
  );
};
